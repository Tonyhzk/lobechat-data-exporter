"""
LobeChat 数据导出工具 - 多文件版本

一个用于解析和导出 LobeChat 数据的桌面应用程序。
"""

__version__ = "3.0.0"
__author__ = "TonyHZK"
